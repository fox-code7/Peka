<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputToDelete = $_POST['input']; // bisa email atau ID

    $dataFile = 'data.json';
    $data = json_decode(file_get_contents($dataFile), true);

    $found = false;
    foreach ($data as $key => $item) {
        if ($item['email'] === $inputToDelete) {
            unset($data[$key]);
            $found = true;
            break;
        }
    }

    file_put_contents($dataFile, json_encode(array_values($data)));

    if ($found) {
        echo json_encode(['success' => true, 'message' => 'Data berhasil dihapus.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Data tidak ditemukan.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Request salah.']);
}
?>