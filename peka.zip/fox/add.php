<?php
$config = include 'config.php';
$dataFile = 'data.json';
$maxEmails = $config['max_emails']; // maksimum data

// Read existing emails from data.json
$data = json_decode(file_get_contents($dataFile), true) ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (count($data) < $maxEmails) {
        $input = $_POST['email']; // tetap pakai field "email"
        $jumlahResult = isset($_POST['jumlahResult']) ? (int)$_POST['jumlahResult'] : 1;

        // Validasi: ID Telegram (angka) atau email
        if (preg_match('/^\d+$/', $input) || filter_var($input, FILTER_VALIDATE_EMAIL)) {
            $data[] = ['email' => $input, 'jumlahResult' => $jumlahResult];

            // Simpan ke data.json
            file_put_contents($dataFile, json_encode($data));

            echo json_encode(['success' => true, 'message' => 'Data Berhasil Ditambahkan.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Format email/ID tidak valid.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Batas maksimum telah tercapai.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menambahkan data.']);
}
?>