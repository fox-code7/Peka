<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel Jatuh Tempo</title>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: url('https://i.ibb.co.com/R0fSq1T/ketat-banget.jpg') no-repeat center center fixed;
        background-size: cover;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
        height: 100vh;
        margin: 0;
        padding: 0;
    }
    .overlay {
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        text-align: center;
        color: #ffffff;
        background-color: rgba(0, 0, 0, 0.6); 
    }
    .container {
        max-width: 400px;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.8); 
        border-radius: 10px;
        box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3);
    }
    .logo {
        max-width: 100px;
        margin-bottom: 20px;
    }
    h1 {
        font-size: 3em;
        margin-bottom: 20px;
        color: #333333; /* Warna teks */
    }
    p {
        font-size: 1.2em;
        line-height: 1.6;
        margin-bottom: 30px;
        color: #666666; /* Warna teks */
    }
    .options {
        display: flex;
        justify-content: center;
        gap: 20px;
    }
    .options a {
        background-color: #007bff;
        color: #ffffff;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 1.2em;
        transition: background-color 0.3s ease;
    }
    .options a:hover {
        background-color: #0056b3;
    }
    .whatsapp-icon {
        color: #25d366;
        font-size: 1.5em;
        margin-right: 10px;
    }
    .error-message {
        font-size: 4em;
        font-weight: bold;
        color: #ffffff;
        margin-bottom: 20px;
    }
</style>
</head>
<body>
    <div class="overlay">
        <img src="https://i.ibb.co.com/qRGL3g7/Chibi-girl-with-a-purple-hoody-and-blue-hair-removebg-preview.png" alt="Logo" class="logo">
        <div class="error-message">Uups..</div>
        <div class="container">
            <h1>Panel Sudah Jatuh Tempo</h1>
            <p>Panel Sudah Harus Di Bayar Untuk Perpanjang</p>
            <p>Silahkan Hubungi Admin Di Bawah Ya</p>
            <div class="options">
                <a href="https://wa.me/6281234872173" class="btn btn-success"><i class="fab fa-whatsapp whatsapp-icon"></i>Hubungi Admin</a>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>
</html>
