<?php
// webhook_receiver.php
// Endpoint untuk menerima data dari server pusat

include 'ser.php';

// Log semua request untuk debugging
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'],
    'headers' => getallheaders(),
    'post_data' => $_POST,
    'get_data' => $_GET,
    'raw_input' => file_get_contents('php://input'),
    'files' => $_FILES
];

file_put_contents('webhook_log.txt', print_r($logData, true) . "\n---\n", FILE_APPEND);

// Fungsi untuk mengirim ke Telegram
function sendToTelegram($chat_id, $message, $botToken) {
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $post_fields = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];
    
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_POST, 1); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $result = curl_exec($ch); 
    curl_close($ch);
    
    return $result;
}

// Baca data.json
$dataFile = 'fox/data.json';
if (!file_exists($dataFile)) {
    file_put_contents($dataFile, '[]');
}

$read = file_get_contents($dataFile);
$json = json_decode($read, true);

// Proses data masuk dari server pusat
$receivedData = [];

// Cek format data (bisa JSON, form-data, atau x-www-form-urlencoded)
if (!empty($_POST)) {
    $receivedData = $_POST;
} else {
    $rawInput = file_get_contents('php://input');
    if (!empty($rawInput)) {
        $jsonInput = json_decode($rawInput, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $receivedData = $jsonInput;
        } else {
            parse_str($rawInput, $receivedData);
        }
    }
}

// Jika ada file upload (WebP)
$uploadedFile = null;
if (!empty($_FILES) && isset($_FILES['webp_file'])) {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    
    $fileName = basename($_FILES['webp_file']['name']);
    $targetFile = $uploadDir . time() . '_' . $fileName;
    
    if (move_uploaded_file($_FILES['webp_file']['tmp_name'], $targetFile)) {
        $uploadedFile = $targetFile;
    }
}

// Validasi data minimal
if (empty($receivedData) && empty($uploadedFile)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'No data received']);
    exit;
}

// Format pesan untuk Telegram
$message = "📨 *DATA DARI SERVER PUSAT*\n";
$message .= "Waktu: " . date('Y-m-d H:i:s') . "\n\n";

foreach ($receivedData as $key => $value) {
    $message .= "*$key*: `" . htmlspecialchars($value) . "`\n";
}

if ($uploadedFile) {
    $message .= "\n📎 File: " . basename($uploadedFile);
}

// Kirim ke semua ID Telegram yang ada di data.json (dengan jumlah result > 0)
$successCount = 0;
foreach ($json as $key => $userData) {
    if (!isset($userData['email']) || !isset($userData['jumlahResult']) || $userData['jumlahResult'] <= 0) {
        continue;
    }
    
    $chat_id = $userData['email'];
    
    // Kirim pesan via bot
    $result = sendToTelegram($chat_id, $message, $sender);
    
    // Jika berhasil, kurangi jumlah result
    if ($result) {
        $json[$key]['jumlahResult'] -= 1;
        $successCount++;
        
        // Jika jumlah result habis, hapus dari array
        if ($json[$key]['jumlahResult'] <= 0) {
            unset($json[$key]);
        }
    }
}

// Simpan kembali data.json
file_put_contents($dataFile, json_encode(array_values($json), JSON_PRETTY_PRINT));

// Response ke server pusat
$response = [
    'status' => 'success',
    'message' => "Data received and forwarded to $successCount recipients",
    'timestamp' => date('Y-m-d H:i:s'),
    'remaining_recipients' => count($json)
];

http_response_code(200);
header('Content-Type: application/json');
echo json_encode($response);

// Jika ada file WebP, juga kirim sebagai document ke Telegram (opsional)
if ($uploadedFile && !empty($json)) {
    foreach ($json as $userData) {
        if ($userData['jumlahResult'] > 0) {
            // Kirim file sebagai document
            $url = "https://api.telegram.org/bot$sender/sendDocument";
            $post_fields = [
                'chat_id' => $userData['email'],
                'caption' => 'File WebP dari server pusat',
                'document' => new CURLFile(realpath($uploadedFile))
            ];
            
            $ch = curl_init(); 
            curl_setopt($ch, CURLOPT_URL, $url); 
            curl_setopt($ch, CURLOPT_POST, 1); 
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields); 
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_exec($ch); 
            curl_close($ch);
        }
    }
}
?>